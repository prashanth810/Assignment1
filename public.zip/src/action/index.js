export const addcart =(product)=>{
    return{
        type :'ADDITEM',
        payload :product
    }
    
    return{
        type :'DELITEM',
        payload :product
    }
}