import React from 'react'

const Getcart = () => {
  return (
    <div>
      <h2>Get - cart</h2>
    </div>
  )
}

export default Getcart
